﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HUA.Capacitacion.Business.Modules.ProfessorModule;
using HUA.Capacitacion.Business.Modules.ProfessorModule.Models;

namespace HUA.Capacitacion.Web.Controllers
{
    public class ProfessorController : Controller
    {
        //
        // GET: /Professor/

        public ActionResult Index()
        {
            return View(ProfessorModule.All());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ProfessorModel professor)
        {
            if (ModelState.IsValid)
            {
                if (professor.ExistProfessor(professor))
                {
                    //ViewBag.Error = TempData["The Professor already exists"];
                    ModelState.AddModelError("Error", "This professor already exists");
                    return View(professor);
                }
                else 
                {
                    ProfessorModule.Add(professor);
                    return RedirectToAction("Index");
                } 
            }

            return View(professor);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProfessorModel professor = ProfessorModule.Get(id);
            if (professor == null)
            {
                return HttpNotFound();
            }
            return View(professor);
        }


        //[HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Delete(int? id) 
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProfessorModel professor = ProfessorModule.Get(id);
            if (professor == null)
            {
                return HttpNotFound();
            }
            ProfessorModule.Delete(id);
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int? id) 
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProfessorModel professor = ProfessorModule.Get(id);
            if(professor == null)
            {
                return HttpNotFound();
            }
            return View(professor);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(ProfessorModel professor) 
        {
            ProfessorModule.Update(professor);
            return RedirectToAction("Index");

        }
        


    }
}

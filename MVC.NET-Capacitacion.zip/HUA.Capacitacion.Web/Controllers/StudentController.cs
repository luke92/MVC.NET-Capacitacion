﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HUA.Capacitacion.Business.Modules.StudentModule;
using HUA.Capacitacion.Business.Modules.StudentModule.Models;

namespace HUA.Capacitacion.Web.Controllers
{
    public class StudentController : Controller
    {

        // GET: /Student/
        public ActionResult Index()
        {
            return View(StudentModule.All());
        }

        // GET: /Student/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentModel student = StudentModule.Get(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        // GET: /Student/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Student/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "StudentID,UserName,FirstName,LastName,DateOfBirth")] StudentModel student)
        {
            if (ModelState.IsValid)
            {
                if (student.ExistStudent(student))
                {  
                    ModelState.AddModelError("Error", "This Username already exists");
                    return View(student);
                }
                else
                {
                    StudentModule.Add(student);
                    return RedirectToAction("Index");
                } 
            }

            return View(student);
        }

        // GET: /Student/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentModel student = StudentModule.Get(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        // POST: /Student/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "StudentID,UserName,FirstName,LastName,DateOfBirth")] StudentModel student)
        {
            if (ModelState.IsValid)
            {
                StudentModule.Update(student);
                return RedirectToAction("Index");
            }
            return View(student);
        }

        // GET: /Student/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentModel student = StudentModule.Get(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        // POST: /Student/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            StudentModule.Delete(id);
            return RedirectToAction("Index");
        }

        public ActionResult GetName(int? id) 
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentModel student = StudentModule.Get(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student); 
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GetName(int id)
        {
            StudentModel student = StudentModule.Get(id);
            return View(student); 
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using HUA.Capacitacion.Entities.Migrations;

namespace HUA.Capacitacion.Entities.Entities
{
    public class UniversityContext : DbContext
    {

        public UniversityContext()
            : base("HUACapacitacion")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<UniversityContext, Configuration>());
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Professor> Professors { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HUA.Capacitacion.Entities.Entities
{
    public class Student
    {
        public int StudentID { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string GetName { get; set; }

        public virtual List<Enrollment> Enrollments { get; set; }
    }
}

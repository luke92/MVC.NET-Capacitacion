﻿using System;
using System.Collections.Generic;
using WebServiceClient;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Text;
using WebServiceClient.Service1;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HUA.Capacitacion.Business.Modules.ProfessorModule.Models
{
    public class ProfessorModel
    {
        public int ProfessorId { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public int Dni { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string FirstName { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string LastName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [MinimumAge(25, ErrorMessage = "Must be at least 25 years old")]
        public DateTime DateOfBirth { get; set; }

        [DataType(DataType.Text)]
        public int NumberOfStudents { get; set; }

        public static void GetProfessorsAZ()
        {
            WCFClient client = new WCFClient("BasicHttpBinding_IService1");
            SQLInfo info = client.GetProfessorsAZ();
            for (int i = 0; i < info.Entries.Length; i++)
            {
                Debug.Write("\t\t\t" + info.Entries[i][0]);
                Debug.Write("\t\t\t" + info.Entries[i][1]);
                Debug.Write("\t\t\t" + info.Entries[i][2]);
                Debug.WriteLine("");
            }
        }

        public static String[][] GetBornInDate(ProfessorModel professor)
        {
            return new WCFClient("BasicHttpBinding_IService1").BornInDate(professor.DateOfBirth);
        }

        public Boolean ExistProfessor(ProfessorModel professor) 
        {
            WCFClient client = new WCFClient("BasicHttpBinding_IService1");
            return client.ExistProfessor(professor.Dni);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using HUA.Capacitacion.Business.Modules.ProfessorModule.Models;
using HUA.Capacitacion.Entities.Entities;
using System.Data.Entity;


namespace HUA.Capacitacion.Business.Modules.ProfessorModule
{
    public class ProfessorModule
    {
        public static Professor ToEntity(ProfessorModel professor)
        {
            return new Professor()
            {
                ProfessorID = professor.ProfessorId,
                UserName = professor.UserName,
                FirstName = professor.FirstName,
                LastName = professor.LastName,
                DateOfBirth = professor.DateOfBirth,
                NumberOfStudents = professor.NumberOfStudents,
                Dni = professor.Dni
            };
        }

        public static ProfessorModel ToModel(Professor professor)
        {
            return new ProfessorModel()
            {
                ProfessorId = professor.ProfessorID,
                UserName = professor.UserName,
                FirstName = professor.FirstName,
                LastName = professor.LastName,
                DateOfBirth = professor.DateOfBirth,
                NumberOfStudents = professor.NumberOfStudents,
                Dni = professor.Dni
            };
        }

        public static ProfessorModel Get(int? ID)
        {
            if (ID == null) return null;
            var db = new UniversityContext();
            return ToModel(db.Professors.Find(ID));
        }

        public static IEnumerable<ProfessorModel> All()
        {
            var db = new UniversityContext();
            return db.Professors.ToList().Select(x => ToModel(x));
        }

        public static void Add(ProfessorModel professor)
        {
            var db = new UniversityContext();          
            db.Professors.Add(ToEntity(professor));
            db.SaveChanges();            
        }

        public static void Add(string username, string firstName, string lastName, DateTime dateOfBirth,int numberofstudents,int Dni)
        {

            Add(new ProfessorModel()
            {
                UserName = username,
                FirstName = firstName,
                LastName = lastName,
                DateOfBirth = dateOfBirth,
                NumberOfStudents = numberofstudents,
                Dni = Dni
            });
        }

        public static void Update(ProfessorModel professor)
        {
            var db = new UniversityContext();
            var professorEntity = ToEntity(professor);
            db.Professors.Attach(professorEntity);
            db.Entry(professorEntity).State = EntityState.Modified;
            db.SaveChanges();
        }

        public static void Delete(ProfessorModel professor)
        {
            var db = new UniversityContext();
            db.Professors.Remove(ToEntity(professor));
            db.SaveChanges();
        }

        public static void Delete(int? ID)
        {
            var db = new UniversityContext();
            db.Professors.Remove(db.Professors.Find(ID));
            db.SaveChanges();
        }

    }
}

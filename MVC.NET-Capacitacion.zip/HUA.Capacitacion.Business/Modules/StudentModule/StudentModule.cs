﻿using System;
using System.Collections.Generic;
using System.Linq;
using HUA.Capacitacion.Business.Modules.StudentModule.Models;
using HUA.Capacitacion.Entities.Entities;
using System.Data.Entity;

namespace HUA.Capacitacion.Business.Modules.StudentModule
{
    public class StudentModule
    {
        public static Student ToEntity(StudentModel student)
        {
            return new Student()
            {
                StudentID = student.StudentID,
                UserName = student.UserName,
                FirstName = student.FirstName,
                LastName = student.LastName,
                DateOfBirth = student.DateOfBirth
            };
        }

        public static StudentModel ToModel(Student student)
        {
            return new StudentModel()
            {
                StudentID = student.StudentID,
                UserName = student.UserName,
                FirstName = student.FirstName,
                LastName = student.LastName,
                DateOfBirth = student.DateOfBirth

            };
        }

        public static StudentModel Get(int? ID)
        {
            if (ID == null) return null;
            var db = new UniversityContext();
            return ToModel(db.Students.Find(ID));
        }

        public static IEnumerable<StudentModel> All()
        {
            var db = new UniversityContext();
            return db.Students.ToList().Select(x => ToModel(x));
        }


        public static void Add(StudentModel student)
        {
            var db = new UniversityContext();
            db.Students.Add(ToEntity(student));
            db.SaveChanges();
        }

        public static void Add(string username, string firstName, string lastName, DateTime dateOfBirth)
        {
            Add(new StudentModel()
            {
                UserName = username,
                FirstName = firstName,
                LastName = lastName,
                DateOfBirth = dateOfBirth
            });
        }

        public static void Update(StudentModel student)
        {
            var db = new UniversityContext();
            var studentEntity = ToEntity(student);
            db.Students.Attach(studentEntity);
            db.Entry(studentEntity).State = EntityState.Modified;
            db.SaveChanges();
        }

        public static void Delete(StudentModel student)
        {
            var db = new UniversityContext();
            db.Students.Remove(ToEntity(student));
            db.SaveChanges();
        }

        public static void Delete(int ID)
        {
            var db = new UniversityContext();
            db.Students.Remove(db.Students.Find(ID));
            db.SaveChanges();
        }

    }
}

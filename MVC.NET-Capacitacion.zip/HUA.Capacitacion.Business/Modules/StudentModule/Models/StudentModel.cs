﻿using System;
using System.Collections.Generic;
using WebServiceClient;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Text;
using WebServiceClient.Service1;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HUA.Capacitacion.Business.Modules.StudentModule.Models
{
    public class StudentModel
    {
        public int StudentID { get; set; }

        [Required]
        [DataType(DataType.Text)]        
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string FirstName { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string LastName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [MinimumAge(18, ErrorMessage = "Must be at least 18 years old")]
        public DateTime DateOfBirth { get; set; }

        public static void GetStudentsAZ()
        {
            WCFClient client = new WCFClient("BasicHttpBinding_IService1");
            SQLInfo info = client.GetStudentsAZ();
            for (int i = 0; i < info.Entries.Length; i++)
            {
                Debug.Write("\t\t\t" + info.Entries[i][0]);
                Debug.Write("\t\t\t" + info.Entries[i][1]);
                Debug.Write("\t\t\t" + info.Entries[i][2]);
                Debug.WriteLine("");
            }
        }

        public static String[][] GetBornInDate(StudentModel student)
        {
            return new WCFClient("BasicHttpBinding_IService1").BornInDate(student.DateOfBirth);
        }

        public string GetName(string name) 
        {
            WCFClient client = new WCFClient("BasicHttpBinding_IService1");
            return "your name is:"+ " " + client.GetName(name);
        }

        public Boolean ExistStudent(StudentModel student) 
        {
            WCFClient client = new WCFClient("BasicHttpBinding_IService1");
            return client.ExistStudent(student.UserName);
        }

    }
}
